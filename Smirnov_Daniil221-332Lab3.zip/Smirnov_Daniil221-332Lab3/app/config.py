#import os

SECRET_KEY = b'f3aa0ebdcc174d0c29d0340243d3da2b4e9d7b63f1acc158af35fd6169f74dd8'
#SECRET_KEY = os.environ.get('SECRET_KEY')

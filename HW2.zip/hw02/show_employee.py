def show_employee(name: str, salary=100000) -> str:
    return f'{name}: {salary} ₽'
    

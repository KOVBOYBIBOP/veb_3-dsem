import operator

def person_lister(formatter):
    def inner(people):
        return [formatter(people) for people in sorted(people, key=lambda x: x[2])]
    return inner

@person_lister
def format_name(person):
    return ("Mr. " if person[3] == "M" else "Ms. ") + person[0] + " " + person[1]

if __name__ == '__main__':
    num_people = int(input())
    people_data = [input().split() for _ in range(num_people)]
    formatted_names = format_name(people_data)
    print(*formatted_names, sep='\n')


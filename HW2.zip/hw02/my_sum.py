def my_sum(*args):
    return sum(args)




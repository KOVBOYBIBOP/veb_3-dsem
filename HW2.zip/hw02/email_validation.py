import re

def fun(email):
    pattern = r'^[a-zA-Z0-9_-]+@[a-zA-Z0-9]+\.[a-zA-Z]{1,3}$'
    return bool(re.match(pattern, email))


def filter_mail(emails_list):
    return list(filter(is_valid_email, emails_list))

if __name__ == '__main__':
    num_emails = int(input())
    emails = []
    for _ in range(num_emails):
        emails.append(input())

    valid_emails = filter_valid_emails(emails)
    valid_emails.sort()
    print(valid_emails)



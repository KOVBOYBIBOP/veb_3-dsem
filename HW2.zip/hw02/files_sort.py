import os
import sys

def list_files_by_extension(directory):
    files_by_extension = {}
    if os.path.isdir(directory):
        for filename in sorted(os.listdir(directory)):
            filepath = os.path.join(directory, filename)
            if os.path.isfile(filepath) and not os.path.islink(filepath):
                _, extension = os.path.splitext(filename)
                files_by_extension.setdefault(extension, []).append(filename)
        for extension, filenames in sorted(files_by_extension.items()):
            print('\n'.join(sorted(filenames)))

if __name__ == "__main__":
    directory = sys.argv[1] if len(sys.argv) >= 2 else None
    if not directory:
        print("Usage: python script.py <directory>")
        sys.exit(1)
    list_files_by_extension(directory)


def wrapper(f):
    def fun(l):
        formatted_numbers = []
        for number in l:
            formatted_number = '+7 ('
            for index, digit in enumerate(number):
                if index == 0 and digit in ['0', '7', '8']:
                    continue
                if len(formatted_number) == 7:
                    formatted_number += ') '
                elif len(formatted_number) in (12, 15):
                    formatted_number += '-'
                formatted_number += digit
            formatted_numbers.append(formatted_number)
        return sorted(formatted_numbers)
    return fun

@wrapper
def sort_phone(l):
    return sorted(l)

if __name__ == '__main__':
    n = int(input())
    phone_numbers = [input() for i in range(n)]
    sorted_numbers = sort_phone(phone_numbers)
    print(*sorted_numbers, sep='\n')


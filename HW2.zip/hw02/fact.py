from functools import lru_cache
import time

@lru_cache(10000)
def fact_rec(n: int) -> int:
    """
    Recursively calculates the factorial of n
    :param n: int
    :return: int
    """
    if n == 1:
        return n
    return n * fact_rec(n - 1)

def fact_it(n: int) -> int:
    """
    Iteratively calculates the factorial of n
    :param n: int
    :return: int
    """
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result
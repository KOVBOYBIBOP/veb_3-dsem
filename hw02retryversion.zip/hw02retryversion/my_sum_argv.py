import sys

def my_sum_argv():
    # Получаем аргументы командной строки, начиная с первого (первый аргумент - имя скрипта)
    args = sys.argv[1:]

    # Преобразуем каждый аргумент в целое число и вычисляем сумму
    total_sum = sum(int(arg) for arg in args)

    # Выводим результат на стандартный поток вывода
    print(total_sum)

if __name__ == "__main__":
    my_sum_argv()

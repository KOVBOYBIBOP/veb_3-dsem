import re

def is_valid_email(email):
    pattern = r'^[a-zA-Z0-9_-]+@[a-zA-Z0-9]+\.[a-zA-Z]{1,3}$'
    return bool(re.match(pattern, email))

def filter_valid_emails(emails_list):
    valid_emails = [email for email in emails_list if is_valid_email(email)]
    valid_emails.sort()
    return valid_emails

if __name__ == '__main__':
    num_emails = int(input().strip())  # Считываем количество адресов электронной почты
    emails = []
    for _ in range(num_emails):
        email = input().strip()
        if email:  # Проверяем, что введена непустая строка
            emails.append(email)

    valid_emails = filter_valid_emails(emails)
    print(valid_emails)

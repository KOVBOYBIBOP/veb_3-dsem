import math

class Dot:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def sub(self, other):
        return Dot(self.x - other.x, self.y - other.y, self.z - other.z)

    def dot_product(self, other):
        return self.x * other.x + self.y * other.y + self.z * other.z

    def cross_product(self, other):
        return Dot(self.y * other.z - self.z * other.y,
                   self.z * other.x - self.x * other.z,
                   self.x * other.y - self.y * other.x)

    def length(self):
        return math.sqrt(self.x ** 2 + self.y ** 2 + self.z ** 2)


def angle_between_planes(a, b, c, d):
    ab = b.sub(a)
    bc = b.sub(c)
    cd = d.sub(c)
    x_vec = ab.cross_product(bc)
    y_vec = bc.cross_product(cd)
    cosine_angle = x_vec.dot_product(y_vec) / (x_vec.length() * y_vec.length())
    return math.acos(cosine_angle)

if __name__ == '__main__':
    PointA = Dot(*map(int, input().split()))
    PointB = Dot(*map(int, input().split()))
    PointC = Dot(*map(int, input().split()))
    PointD = Dot(*map(int, input().split()))

    angle_radians = angle_between_planes(PointA, PointB, PointC, PointD)
    angle_degrees = math.degrees(angle_radians)
    print(angle_degrees)

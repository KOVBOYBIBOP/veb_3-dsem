from datetime import datetime

def function_logger(log_file):
    def real_decorator(func):
        def wrapper(*args, **kwargs):
            with open(log_file, 'w') as file:
                file.write(f'{func.__name__}\n')
                start_time = datetime.now()
                file.write(f'{start_time.strftime("%Y-%m-%d %H:%M:%S.%f")}\n')
                file.write(f'{args}\n' if args else '')
                file.write(f'{kwargs}\n' if kwargs else '')
                result = func(*args, **kwargs)
                file.write(f'{result}\n' if result else '-\n')
                end_time = datetime.now()
                file.write(f'{end_time.strftime("%Y-%m-%d %H:%M:%S.%f")}\n')
                file.write(f'{str(end_time - start_time)}\n')
            return result
        return wrapper
    return real_decorator

@function_logger("log.txt")
def format_greeting(name):
    return f'Hello, {name}!'

if __name__ == '__main__':
    name = input()
    greeting = format_greeting(name)
    print(greeting)


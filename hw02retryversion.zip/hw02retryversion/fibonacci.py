cubic_function = lambda x: x * x * x

def generate_fibonacci_sequence(length):
   if length == 1:
       return [0]
   if length == 2:
       return [0, 1]
   fibonacci_sequence = [0, 1]
   for _ in range(length - 2):
       fibonacci_sequence.append(fibonacci_sequence[-1] + fibonacci_sequence[-2])
   return fibonacci_sequence

if __name__ == '__main__':
    sequence_length = int(input())
    fibonacci_numbers = generate_fibonacci_sequence(sequence_length)
    result = list(map(cubic_function, fibonacci_numbers))
    print(result)


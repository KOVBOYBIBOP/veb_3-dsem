def wrapper(f):
    def fun(l):
        a = []
        for i in range(len(l)):
            if (l[i][0:2] == '+7'):
                k=0
            elif (len(l[i]) == 11): # есть префикcа
                l[i] = l[i].replace(l[i][0],"+7",1)
            elif (len(l[i]) == 10): # нет префикcа
                l[i] = "+7" + l[i]
            s = f"{l[i][0:2]} ({l[i][2:5]}) {l[i][5:8]}-{l[i][8:10]}-{l[i][10:]}"
            a.append(s)
        return tuple(f(a))
    return fun

@wrapper
def sort_phone(l):
    return sorted(l)

if __name__ == '__main__':
    n = int(input())
    arr = []
    for i in range(n):
        arr.append(input())
    for i in sort_phone(arr):
        print(i)
